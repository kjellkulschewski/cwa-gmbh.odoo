{
    'name': 'Hello App',
    'summary': 'Display a hello message',
    'version': '1.0',
    'category': 'Website',
    'author': 'Your Name',
    'depends': ['base', 'web'],
    'data': [
        'views/hello_view.xml',
    ],
    'installable': True,
    'auto_install': False,
    'application': True,
}
